﻿namespace SocoShop.Page
{
    using System;

    public class Message : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

