﻿namespace SocoShop.Page
{
    using System;

    public class UserApply : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

