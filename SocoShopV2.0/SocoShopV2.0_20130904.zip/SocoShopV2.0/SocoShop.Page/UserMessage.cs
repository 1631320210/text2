﻿namespace SocoShop.Page
{
    using System;

    public class UserMessage : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

