﻿namespace SocoShop.Page
{
    using System;

    public class UserCoupon : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

