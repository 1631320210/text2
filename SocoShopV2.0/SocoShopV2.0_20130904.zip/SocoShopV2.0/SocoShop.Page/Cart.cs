﻿namespace SocoShop.Page
{
    using System;

    public class Cart : CommonBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
            base.Title = "购物车";
        }
    }
}

