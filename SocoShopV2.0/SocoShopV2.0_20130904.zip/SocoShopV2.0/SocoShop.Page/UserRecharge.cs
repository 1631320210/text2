﻿namespace SocoShop.Page
{
    using System;

    public class UserRecharge : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

