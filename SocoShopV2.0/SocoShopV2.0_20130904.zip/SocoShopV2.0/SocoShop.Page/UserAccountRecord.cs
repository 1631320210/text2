﻿namespace SocoShop.Page
{
    using System;

    public class UserAccountRecord : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

