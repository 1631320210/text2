﻿namespace SocoShop.Page
{
    using System;

    public class Brand : CommonBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
            base.Title = "品牌专区";
        }
    }
}

