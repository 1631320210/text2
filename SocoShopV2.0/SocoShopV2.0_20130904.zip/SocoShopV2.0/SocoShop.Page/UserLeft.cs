﻿namespace SocoShop.Page
{
    using System;

    public class UserLeft : UserBasePage
    {
        protected override void PageLoad()
        {
            base.PageLoad();
        }
    }
}

