﻿namespace SkyCES.EntLib
{
    using System;

    public enum BoolType
    {
        False,
        True
    }
}

