﻿namespace SkyCES.EntLib
{
    using System;

    public enum LogFileNameType
    {
        ByDay = 1,
        ByGuid = 2
    }
}

