﻿namespace SkyCES.EntLib
{
    using System;

    public enum AdType
    {
        Code = 4,
        Flash = 3,
        Picture = 2,
        Text = 1
    }
}

