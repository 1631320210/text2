﻿namespace SkyCES.EntLib
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ProcessFinishedHandler(object sender, EventArgs e);
}

