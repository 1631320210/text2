﻿namespace SkyCES.EntLib
{
    using System;

    public enum CodeType
    {
        Letter = 2,
        Mixed = 3,
        Number = 1
    }
}

