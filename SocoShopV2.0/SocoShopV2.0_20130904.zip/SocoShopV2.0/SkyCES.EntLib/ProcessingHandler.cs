﻿namespace SkyCES.EntLib
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ProcessingHandler(object sender, ProcessingEventArgs e);
}

