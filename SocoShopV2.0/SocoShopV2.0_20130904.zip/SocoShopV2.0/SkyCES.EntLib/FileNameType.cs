﻿namespace SkyCES.EntLib
{
    using System;

    public enum FileNameType
    {
        Date = 1,
        FileNameAndDate = 2,
        Guid = 5,
        MD516 = 3,
        MD532 = 4,
        OriginalFileName = 6
    }
}

