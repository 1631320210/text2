﻿namespace SkyCES.EntLib
{
    using System;

    public class WinMessage : IMessage
    {
        public void Show(string message)
        {
        }
    }
}

