﻿namespace SkyCES.EntLib
{
    using System;

    public enum OrderType
    {
        Desc,
        Asc
    }
}

