﻿namespace SkyCES.EntLib
{
    using System;

    public interface IMessage
    {
        void Show(string message);
    }
}

