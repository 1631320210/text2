﻿namespace SkyCES.EntLib
{
    using System;

    public enum PasswordType
    {
        Clear,
        MD516,
        MD532,
        MD5Twice,
        SHA1
    }
}

