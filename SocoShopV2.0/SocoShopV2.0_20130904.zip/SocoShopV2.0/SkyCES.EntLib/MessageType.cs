﻿namespace SkyCES.EntLib
{
    using System;

    public enum MessageType
    {
        WebType = 1,
        WinType = 2
    }
}

