﻿namespace SkyCES.EntLib
{
    using System;

    public enum ThumbnailType
    {
        AllFix,
        WidthFix,
        HeightFix,
        InBox,
        OutBox
    }
}

