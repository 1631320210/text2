﻿namespace SkyCES.EntLib
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void PreWriteHandler(object sender, PreWriteEventArgs e);
}

