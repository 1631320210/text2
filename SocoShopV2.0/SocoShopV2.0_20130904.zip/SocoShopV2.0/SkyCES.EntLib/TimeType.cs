﻿namespace SkyCES.EntLib
{
    using System;

    public enum TimeType
    {
        Year,
        Month,
        Day,
        Hour,
        Minute,
        Second,
        Millisecond
    }
}

