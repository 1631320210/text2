﻿namespace SocoShop.Entity
{
    using System;

    public enum VoteType
    {
        CheckBox = 2,
        Radio = 1
    }
}

