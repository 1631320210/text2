﻿namespace SocoShop.Entity
{
    using System;

    public enum OrderOperate
    {
        Back = 8,
        Cancle = 3,
        Change = 6,
        Check = 2,
        Pay = 1,
        Received = 5,
        Refund = 9,
        Return = 7,
        Send = 4
    }
}

