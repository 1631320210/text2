﻿namespace SocoShop.Entity
{
    using System;

    public enum ProductStorageType
    {
        ImportStorageSystem = 2,
        SelfStorageSystem = 1
    }
}

