﻿namespace SocoShop.Entity
{
    using System;

    public enum DateType
    {
        Day = 1,
        Month = 2
    }
}

