﻿namespace SocoShop.Entity
{
    using System;

    public enum ChangeAction
    {
        Up,
        Down,
        Plus,
        Minus
    }
}

