﻿namespace SocoShop.Entity
{
    using System;

    public enum ShippingType
    {
        Fixed = 1,
        ProductCount = 3,
        Weight = 2
    }
}

