﻿namespace SocoShop.Entity
{
    using System;

    public enum CouponType
    {
        Offline = 2,
        Online = 1
    }
}

