﻿namespace SocoShop.Entity
{
    using System;

    public enum FavorableShipping
    {
        No,
        Free
    }
}

