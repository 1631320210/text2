﻿namespace SocoShop.Entity
{
    using SkyCES.EntLib;
    using System;

    public enum DisplayTye
    {
        [Enum("图片")]
        Image = 2,
        [Enum("文字")]
        Text = 1
    }
}

