﻿namespace SocoShop.Entity
{
    using System;

    public enum AccountType
    {
        Money = 1,
        Point = 2
    }
}

