﻿namespace SocoShop.Entity
{
    using System;

    public enum FavorableMoney
    {
        No,
        Money,
        Discount
    }
}

