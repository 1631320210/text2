﻿namespace SocoShop.Entity
{
    using System;

    public enum StorageAnalyseType
    {
        Lack = 1,
        Over = 3,
        Safe = 2
    }
}

