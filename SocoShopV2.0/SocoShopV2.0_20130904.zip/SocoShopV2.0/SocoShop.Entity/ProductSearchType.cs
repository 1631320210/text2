﻿namespace SocoShop.Entity
{
    using System;

    public enum ProductSearchType
    {
        Key = 2,
        Special = 1
    }
}

