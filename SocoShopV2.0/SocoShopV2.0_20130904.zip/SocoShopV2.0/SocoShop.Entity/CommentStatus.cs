﻿namespace SocoShop.Entity
{
    using System;

    public enum CommentStatus
    {
        NoHandler = 1,
        NoShow = 3,
        Show = 2
    }
}

