﻿namespace SocoShop.Entity
{
    using System;

    public enum ProductShowWay
    {
        List = 2,
        Picture = 1
    }
}

