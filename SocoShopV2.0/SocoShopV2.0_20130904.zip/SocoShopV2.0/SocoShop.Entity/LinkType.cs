﻿namespace SocoShop.Entity
{
    using System;

    public enum LinkType
    {
        Picture = 2,
        Text = 1
    }
}

