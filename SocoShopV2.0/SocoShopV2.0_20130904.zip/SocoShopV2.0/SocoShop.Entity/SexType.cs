﻿namespace SocoShop.Entity
{
    using SkyCES.EntLib;
    using System;

    public enum SexType
    {
        [Enum("男")]
        Men = 1,
        [Enum("保密")]
        Secret = 3,
        [Enum("女")]
        Women = 2
    }
}

