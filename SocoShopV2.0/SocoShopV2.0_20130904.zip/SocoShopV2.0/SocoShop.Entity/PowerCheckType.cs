﻿namespace SocoShop.Entity
{
    using System;

    public enum PowerCheckType
    {
        Single,
        OR,
        AND
    }
}

