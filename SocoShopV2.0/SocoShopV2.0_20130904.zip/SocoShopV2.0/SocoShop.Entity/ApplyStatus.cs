﻿namespace SocoShop.Entity
{
    using System;

    public enum ApplyStatus
    {
        Accomplish = 2,
        Cancle = 3,
        Indeterminate = 1
    }
}

