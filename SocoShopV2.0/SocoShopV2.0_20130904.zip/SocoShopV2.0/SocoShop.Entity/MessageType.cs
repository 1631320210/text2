﻿namespace SocoShop.Entity
{
    using System;

    public enum MessageType
    {
        AfterSale = 4,
        Complain = 2,
        DemandBuy = 5,
        Inquire = 3,
        Message = 1
    }
}

